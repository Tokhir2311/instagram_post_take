from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackContext
import os
import subprocess

async def start(update: Update, context: CallbackContext) -> None:
    await update.message.reply_text("Assalomu alaykum! Instagram video yuklab beruvchi botga xush kelibsiz. Post havolasini yuboring!")

def download_instagram_video(url: str) -> str:
    output_path = "downloaded_video.mp4"
    command = ["yt-dlp", "-f", "best", "-o", output_path, url]
    subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return output_path if os.path.exists(output_path) else None

async def handle_message(update: Update, context: CallbackContext) -> None:
    url = update.message.text
    await update.message.reply_text("Videoni yuklab olish jarayoni boshlandi...")
    video_path = download_instagram_video(url)
    if video_path:
        await update.message.reply_video(video=open(video_path, "rb"))
        os.remove(video_path)
    else:
        await update.message.reply_text("Kechirasiz, videoni yuklab bo‘lmadi. Iltimos, havolani tekshirib qaytadan yuboring.")

def main():
    app = Application.builder().token("7528070227:AAHtMAe23natGdLXvF-0nUq8qsm-Yp6gRBQ").build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    app.run_polling()

if __name__ == "__main__":
    main()